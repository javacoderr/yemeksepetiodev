public class Statics {

    public static final String CURRENT_MAIL = "kerimaydinceng";
    public static final String CURRENT_DOMAIN = "@gmail.com";
    public static final String UNCURRENT_MAIL = "kerimaydincengg";
    public static final String CURRENT_PASSWORD = "123Qwe??";
    public static final String UNCURRENT_PASSWORD = "asdwer";

}
